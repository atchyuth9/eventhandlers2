import React, { Fragment } from "react";
import Changeselectbox from "./Changeselectbox";
import Event from "./Event";
import Sms from "./Sms";
let App = () => {
  return (
    <Fragment>
      <nav className="nav">
        <a href="/">Achyuth</a>
      </nav>
      <Event />
      <Changeselectbox />
      <Sms />
    </Fragment>
  );
};
export default App;
