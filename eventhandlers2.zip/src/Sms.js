import React, { Fragment } from "react";

class Sms extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      count: 100,
      maxlimit: 100
    };
  }

  updateCount = (event) => {
    this.setState({
      count: this.state.maxlimit - event.target.value.length
    });
  };
  render() {
    return (
      <Fragment>
        <div className="containeer">
          <div className="roww">
            <div className="coll">
              <div className="card">
                <div className="header">
                  <h2>SMS</h2>
                </div>
                <div className="body">
                  <form>
                    <div className="textareea">
                      <textarea
                        onChange={this.updateCount}
                        maxLength={this.state.maxlimit}
                        rows="9"
                        classname="formcontro"
                        placeholder="typehere"
                      ></textarea>
                    </div>
                  </form>
                </div>
                <div className="footer">
                  <h3>
                    Characters remainingg: <span>{this.state.count}</span>
                  </h3>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

export default Sms;
